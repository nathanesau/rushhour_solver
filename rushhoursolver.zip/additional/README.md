# rushhour_solver (Additional Languages)

Solve RushHour puzzles using BFS.

* [cpp](cpp/README.md): contains C++ solver implementation
* [python](python/README.md): contains Python solver implementation